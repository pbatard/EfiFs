Built on 2024.11.29 from the latest edk2/edk2-platforms and using the 2024.11.01 toolchain
from https://github.com/loongson/build-tools/releases.