Repackaged from:
http://ftp.us.debian.org/debian/pool/main/e/edk2/qemu-efi-loongarch64_2026.08+ds-2_all.deb