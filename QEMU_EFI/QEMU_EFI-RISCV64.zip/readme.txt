Downloaded from:
  http://ftp.ie.debian.org/debian/pool/main/e/edk2/qemu-efi-riscv64_2024.02-2_all.deb
and extracted from './usr/share/qemu-efi-riscv64/RISCV_VIRT_CODE.fd' in the archive.
