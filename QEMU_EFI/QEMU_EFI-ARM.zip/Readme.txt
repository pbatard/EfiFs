Because EBC support for ARM is not yet integrated into EDK2, the included
QEMU_EFI.fd firmware was produced from the following branch:
  https://github.com/pbatard/edk2/tree/ebc-arm5
using a gcc 5.4 Arm toolchain on Debian Sid, following the instructions at:
  https://wiki.linaro.org/LEG/UEFIforQEMU
