Downloaded from:
  http://snapshots.linaro.org/components/kernel/leg-virt-tianocore-edk2-upstream/1631/QEMU-AARCH64/RELEASE_GCC5/