Downloaded from:
 http://ftp.ie.debian.org/debian/pool/main/e/edk2/ovmf_2020.11-2_all.deb
 and extracted from './usr/share/OVMF/OVMF.fd' in the archive.
