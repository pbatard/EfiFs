Downloaded from:
  https://www.kraxel.org/repos/jenkins/edk2/edk2.git-ovmf-x64-0-20220719.209.gf0064ac3af.EOL.no.nore.updates.noarch.rpm
and renamed from './usr.share/edk2.git/ovmf-x64/OVMF-pure-efi.fd' in the archive.