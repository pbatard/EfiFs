Because EBC support for ARM is not yet integrated into EDK2, this QEMU_EFI.fd firmware
was custom produced with gcc 5 on a Debian 8 machine, from EDK2 @490acf89
(https://github.com/tianocore/edk2/commit/490acf8908f797982f367bfeb4bdf3ebe0764e42)
with MdeModulePkg-EbcDxe-add-ARM-support.patch applied, and using the instructions
from https://wiki.linaro.org/LEG/UEFIforQEMU.
