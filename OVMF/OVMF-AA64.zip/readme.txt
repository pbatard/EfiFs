Downloaded from:
 https://snapshots.linaro.org/components/kernel/leg-virt-tianocore-edk2-upstream/4194/QEMU-AARCH64/RELEASE_GCC5/QEMU_EFI.fd
 and renamed to OVMF.fd