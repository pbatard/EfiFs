Downloaded from:
 https://www.kraxel.org/repos/jenkins/edk2/edk2.git-ovmf-ia32-0-20200309.1367.gbd6aa93296.noarch.rpm
 and renamed from './usr/share/edk2.git/ovmf-ia32/OVMF-pure-efi.fd' in the archive.
