Downloaded from:
  http://ftp.ie.debian.org/debian/pool/main/e/edk2/ovmf_2023.08-1_all.deb
and extracted from './usr/share/OVMF/OVMF_CODE_4M.fd' in the archive.
